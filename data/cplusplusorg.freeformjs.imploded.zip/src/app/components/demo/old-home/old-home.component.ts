import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-old-home',
  templateUrl: './old-home.component.html',
  styleUrls: ['./old-home.component.css']
})
export class OldHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

