import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-object-storage',
  templateUrl: './object-storage.component.html',
  styleUrls: ['./object-storage.component.css']
})
export class ObjectStorageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

