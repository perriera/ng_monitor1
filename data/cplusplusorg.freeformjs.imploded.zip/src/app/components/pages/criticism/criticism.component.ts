import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-criticism',
  templateUrl: './criticism.component.html',
  styleUrls: ['./criticism.component.css']
})
export class CriticismComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

