import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-2',
  templateUrl: './books-2.component.html',
  styleUrls: ['./books-2.component.css']
})
export class Books2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

