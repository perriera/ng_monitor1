import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-1',
  templateUrl: './books-1.component.html',
  styleUrls: ['./books-1.component.css']
})
export class Books1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

