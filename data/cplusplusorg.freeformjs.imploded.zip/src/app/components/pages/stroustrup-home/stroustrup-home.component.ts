import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stroustrup-home',
  templateUrl: './stroustrup-home.component.html',
  styleUrls: ['./stroustrup-home.component.css']
})
export class StroustrupHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

