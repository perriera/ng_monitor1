import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frequently-requested-papers-1',
  templateUrl: './frequently-requested-papers-1.component.html',
  styleUrls: ['./frequently-requested-papers-1.component.css']
})
export class FrequentlyRequestedPapers1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

