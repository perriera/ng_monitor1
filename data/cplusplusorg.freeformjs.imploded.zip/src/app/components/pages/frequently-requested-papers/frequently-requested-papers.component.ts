import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frequently-requested-papers',
  templateUrl: './frequently-requested-papers.component.html',
  styleUrls: ['./frequently-requested-papers.component.css']
})
export class FrequentlyRequestedPapersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

