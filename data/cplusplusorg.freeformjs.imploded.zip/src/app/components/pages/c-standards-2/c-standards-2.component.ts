import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-standards-2',
  templateUrl: './c-standards-2.component.html',
  styleUrls: ['./c-standards-2.component.css']
})
export class CStandards2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

