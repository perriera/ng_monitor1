import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operators-and-operator-overloading',
  templateUrl: './operators-and-operator-overloading.component.html',
  styleUrls: ['./operators-and-operator-overloading.component.css']
})
export class OperatorsAndOperatorOverloadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

