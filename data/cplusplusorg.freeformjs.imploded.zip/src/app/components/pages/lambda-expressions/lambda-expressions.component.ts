import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lambda-expressions',
  templateUrl: './lambda-expressions.component.html',
  styleUrls: ['./lambda-expressions.component.css']
})
export class LambdaExpressionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

