import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frequently-requested-papers-4',
  templateUrl: './frequently-requested-papers-4.component.html',
  styleUrls: ['./frequently-requested-papers-4.component.css']
})
export class FrequentlyRequestedPapers4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

