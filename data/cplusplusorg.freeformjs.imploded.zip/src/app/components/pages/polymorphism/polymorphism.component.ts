import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-polymorphism',
  templateUrl: './polymorphism.component.html',
  styleUrls: ['./polymorphism.component.css']
})
export class PolymorphismComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

