import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-7',
  templateUrl: './books-7.component.html',
  styleUrls: ['./books-7.component.css']
})
export class Books7Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

