import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c-standards-1',
  templateUrl: './c-standards-1.component.html',
  styleUrls: ['./c-standards-1.component.css']
})
export class CStandards1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

