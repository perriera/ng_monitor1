import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-standard-library',
  templateUrl: './standard-library.component.html',
  styleUrls: ['./standard-library.component.css']
})
export class StandardLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

